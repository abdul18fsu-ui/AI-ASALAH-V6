AI A.SALAH V6

V6 fixes the connection flow. The browser calls /api/chat and the secret API key stays on the server.

Setup:
1. npm install
2. Set OPENAI_API_KEY as a server environment secret.
3. Optional: set OPENAI_MODEL (default: gpt-5).
4. npm start
5. Open the deployed website URL.

Do not put the API key inside public/index.html. Opening index.html directly will show No server connection because it needs the backend.
